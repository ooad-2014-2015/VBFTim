﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using SalonLjepoteBelma.View;
using System.ComponentModel;





namespace SalonLjepoteBelma.ViewModel
{


    class MainWindowViewModel 
    {
        public ICommand Login { get; set; }



        public MainWindowViewModel()
        {   
            //Button komanda
            Login = new RelayCommand(login);
            //njega lica
            njegaLica.Add("Tretman za masnu kozu");
            njegaLica.Add("Tretman za suhu kozu");
            njegaLica.Add("Tretman za osjetljivu kozu");
            njegaLica.Add("Tretman za muskarce");
            njegaLica.Add("Njega Lica");
            //njega tijela
            njegaTijela.Add("Depilacija");
            njegaTijela.Add("Masaza");
            njegaTijela.Add("Kupka");
            njegaTijela.Add("Piling tijela");
            njegaTijela.Add("Njega tijela");
            //manikir i pedikir
            manikirPedikir.Add("Manikir");
            manikirPedikir.Add("Nail art");
            manikirPedikir.Add("Pedikir");
            manikirPedikir.Add("Manikir/Pedikir");
            // frizerske usluge
            frizerskeUsluge.Add("Musko sisanje");
            frizerskeUsluge.Add("Zensko sisanje");
            frizerskeUsluge.Add("Svecane frizure");
            frizerskeUsluge.Add("Nadogradnja kose");
            frizerskeUsluge.Add("Frizerske usluge");
            
           

            

        }
        public Action CloseAction { get; set; }

       
        public void login(object parametar)
        {
            LoginView NovaLoginForma = new LoginView();
            NovaLoginForma.Show();

        }
        private List<String> njegaLica = new List<String>();

        public List<String> NjegaLica
        {
            get { return njegaLica; }
            set { njegaLica = value; }
        }
        
        private List<String> njegaTijela = new List<String>();

        public List<String> NjegaTijela
        {
            get { return njegaTijela; }
            set { njegaTijela = value; }
        }

        private List<String> manikirPedikir = new List<String>();

        public List<String> ManikirPedikir
        {
            get { return manikirPedikir; }
            set { manikirPedikir = value; }
        }

        private List<String> frizerskeUsluge = new List<String>();

        public List<String> FrizerskeUsluge
        {
            get { return frizerskeUsluge; }
            set { frizerskeUsluge = value; }
        }
        

    }
}
