﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using SalonLjepoteBelma.View;

namespace SalonLjepoteBelma.ViewModel
{
    class LoginViewModel
    {
         public ICommand Prijava { get; set; }

         public LoginViewModel()
        {
            Prijava = new RelayCommand(prijava);
        }
        public Action CloseAction { get; set; }

        public void prijava(object parametar)
        {
            //UslugeView NovaUslugaForma = new UslugeView();
            //NovaUslugaForma.Show();
        }
    }
}
