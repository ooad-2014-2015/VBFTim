﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SalonLjepoteBelma.View
{
    /// <summary>
    /// Interaction logic for LoginView.xaml
    /// </summary>
    public partial class LoginView : Window
    {
        public LoginView()
        {
            InitializeComponent();
        }
        //ima fokus na korisnicko ime
        public void KorisnickoImeGot(object sender, RoutedEventArgs e)
        {   
            if(korisnickoIme.Text=="Korisnicko ime")
            korisnickoIme.Text = string.Empty;
            
        }
        //nema fokus na korisnicko ime
        public void KorisnickoImeLost(object sender, RoutedEventArgs e)
        {
            if(korisnickoIme.Text == string.Empty)
                korisnickoIme.Text="Korisnicko ime";
            
        }
        
        public void SifraGot(object sender, RoutedEventArgs e)
        {
            if (sifra.Text == "Sifra")
                sifra.Text = string.Empty;

        }
        
        public void SifraLost(object sender, RoutedEventArgs e)
        {
            if (sifra.Text == string.Empty)
                sifra.Text = "Sifra";
     
        }
        public void ImeGot(object sender, RoutedEventArgs e)
        {
            if (ime.Text == "Ime")
                ime.Text = string.Empty;
        }

        public void ImeLost(object sender, RoutedEventArgs e)
        {
            if (ime.Text == string.Empty)
                ime.Text = "Ime";
        }
        public void PrezimeGot(object sender, RoutedEventArgs e)
        {
            if (prezime.Text == "Prezime")
                prezime.Text = string.Empty;
        }

        public void PrezimeLost(object sender, RoutedEventArgs e)
        {
            if (prezime.Text == string.Empty)
                prezime.Text = "Prezime";
        }
        public void EmailGot(object sender, RoutedEventArgs e)
        {
            if (email.Text == "Email")
                email.Text = string.Empty;
        }

        public void EmailLost(object sender, RoutedEventArgs e)
        {
            if (email.Text == string.Empty)
                email.Text = "Email";
        }
        public void BrojTelefonaGot(object sender, RoutedEventArgs e)
        {
            if (telefon.Text == "Broj telefona")
                telefon.Text = string.Empty;
        }

        public void BrojTelefonaLost(object sender, RoutedEventArgs e)
        {
            if (telefon.Text == string.Empty)
                telefon.Text = "Broj telefona";
        }
        public void BrojKarticeGot(object sender, RoutedEventArgs e)
        {
            if (kartica.Text == "Broj kartice")
                kartica.Text = string.Empty;
        }

        public void BrojKarticeLost(object sender, RoutedEventArgs e)
        {
            if (kartica.Text == string.Empty)
                kartica.Text = "Broj kartice";
        }
        public void KorisnickoImeGot1(object sender, RoutedEventArgs e)
        {
            if (imeRegistracija.Text == "Korisnicko ime")
                imeRegistracija.Text = string.Empty;
        }
        
        public void KorisnickoImeLost1(object sender, RoutedEventArgs e)
        {
            if (imeRegistracija.Text == string.Empty)
                imeRegistracija.Text = "Korisnicko ime";
        }
        public void SifraGot1(object sender, RoutedEventArgs e)
        {
            if (sifraRegistracija.Text == "Sifra")
                sifraRegistracija.Text = string.Empty;
        }

        public void SifraLost1(object sender, RoutedEventArgs e)
        {
            if (sifraRegistracija.Text == string.Empty)
                sifraRegistracija.Text = "Sifra";
        }
      
        
    }
}
