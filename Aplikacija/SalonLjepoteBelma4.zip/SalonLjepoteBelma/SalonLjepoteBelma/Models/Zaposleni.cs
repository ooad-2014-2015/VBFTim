﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalonLjepoteBelma.Models
{
   public class Zaposleni
    {
        private string imePrezime;

        public string ImePrezime
        {
            get { return imePrezime; }
            set { imePrezime = value; }
        }


        public Zaposleni(string naziv)
        {
            imePrezime = naziv;            
        }
        private Int32 plata;

        public Int32 Plata
        {
            get { return plata; }
            set { plata = value; }
        }
        private DateTime datum;

        public DateTime Datum
        {
            get { return datum; }
            set { datum = value; }
        }
        private int idPosla;

        public int IdPosla
        {
            get { return idPosla; }
            set { idPosla = value; }
        }
        private int idOdjela;

        public int IdOdjela
        {
            get { return idOdjela; }
            set { idOdjela = value; }
        }
        public Zaposleni(int i,string ime, Int32 pl, DateTime d, int idP, int idO)
        {
            imePrezime = ime;
            plata = pl;
            datum = d;
            idPosla = idP;
            idOdjela = idO;
            id = i;
        }
        private int id;

        public int Id
        {
            get { return id; }
            set { id = value; }
        }
    }
}
