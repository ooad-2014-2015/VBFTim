﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SalonLjepoteBelma.Models;
using MySql.Data.MySqlClient;
using System.Collections.ObjectModel;
using System.Windows.Input;
using System.Windows;
using SalonLjepoteBelma.View;

namespace SalonLjepoteBelma.ViewModel
{
   public class SefViewModel
    {
  
       string connectionString = "server=localhost;user=root;pwd=;database=salonljepote";
        MySqlConnection con;

        private ObservableCollection<Zaposleni> listaIme;

        public ObservableCollection<Zaposleni> ListaIme
        {
            get { return listaIme; }
            set { listaIme = value; }
        }
        private string idBrisanje;

        public string IdBrisanje
        {
            get { return idBrisanje; }
            set { idBrisanje = value; }
        }
        public ICommand Obrisi { get; set; }
        public ICommand Dodaj { get; set; }
        public ICommand Izlaz { get; set; }
        public ICommand DodajBaza { get; set; }



        public SefViewModel()
        {
            Dodaj= new RelayCommand(dodaj);
            Obrisi = new RelayCommand(obrisi);
            Izlaz = new RelayCommand(izlaz);
            DodajBaza = new RelayCommand(dodajBaza);

            con = new MySqlConnection(connectionString);
            try
            {
                con.Open();
                MySqlCommand upitKomanda = new MySqlCommand("select * from zaposleni", con);
                MySqlDataReader r = upitKomanda.ExecuteReader();
                listaIme = new ObservableCollection<Zaposleni>();
                while (r.Read())
                {
                    Zaposleni k = new Zaposleni(r.GetInt32("ID_zaposlenog"),r.GetString("Ime"), r.GetInt32("Plata"), r.GetDateTime("Datum_zaposlenja"), r.GetInt32("Veza_posao"), r.GetInt32("Veza_odjel"));
                    listaIme.Add(k);

                }
                r.Close();
            }
            catch (Exception) { }
           
        }
        private void obrisi(object parameter)
        {
            try
            {
                MySqlCommand deleteUpit = new MySqlCommand("delete from zaposleni where ID_zaposlenog='" + IdBrisanje +"'", con);
                deleteUpit.ExecuteNonQuery();

                
            }
            catch (Exception) { }
            MessageBoxResult result = MessageBox.Show("Uspjesno ste obrisali radnika iz baze podataka", "Radnik brisanje", MessageBoxButton.OK);
            switch (result)
            {
                case MessageBoxResult.OK:
                    Sef r = new Sef();
                    r.Show();
                    break;
            }
           


        }
        private void dodaj(object parameter)
        {
            SefPomocna sp = new SefPomocna();
            sp.Show();
        }
        private void izlaz(object parameter)
        {
            MessageBoxResult result = MessageBox.Show("Ako zelite zatvoriti aplikaciju kliknite YES,ako zelite ponovo azurirati ili brisati kliknite CANCEL,ako zelite da se odjavite kliknite NO", "Radnik Odjava", MessageBoxButton.YesNoCancel);


            switch (result)
            {
                case MessageBoxResult.Yes:
                    App.Current.Shutdown();
                    break;
                case MessageBoxResult.No:
                    LoginView mw = new LoginView();
                    mw.Show();
                    break;
                case MessageBoxResult.Cancel:
                    Sef iu = new Sef();
                    iu.Show();
                    break;
            }
        }
        private void dodajBaza(object parameter)
        {
            try
            {
                
                //unos korisnika u bazu
                MySqlCommand insertUpit = new MySqlCommand("insert into zaposleni(ID_zaposlenog,Ime,Plata,Datum_zaposlenja,Veza_posao,Veza_odjel) values('" + idTx + "','" + imeTx + "','" + plataTx + "','" + datumTx + "','" + posaoTx + "','" + odjelTx + "')", con);
                insertUpit.ExecuteNonQuery();

                
            }
            catch (Exception) { }
            finally
            {
                con.Close();
            }
            MessageBoxResult result = MessageBox.Show("Uspjesno ste dodali radnika", "Radnik dodaj", MessageBoxButton.OK);
            switch (result)
            {
                case MessageBoxResult.OK:
                    Sef r = new Sef();
                    r.Show();
                    break;
            }
            
        }
        private int idTx;

        public int IdTx
        {
            get { return idTx; }
            set { idTx = value; }
        }
        private string imeTx;

        public string ImeTx
        {
            get { return imeTx; }
            set { imeTx = value; }
        }
        private DateTime datumTx;

        public DateTime DatumTx
        {
            get { return datumTx; }
            set { datumTx = value; }
        }
        private int plataTx;

        public int PlataTx
        {
            get { return plataTx; }
            set { plataTx = value; }
        }
        private int odjelTx;

        public int OdjelTx
        {
            get { return odjelTx; }
            set { odjelTx = value; }
        }
        private int posaoTx;

        public int PosaoTx
        {
            get { return posaoTx; }
            set { posaoTx = value; }
        }


    }
}

