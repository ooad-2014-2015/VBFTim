﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using SalonLjepoteBelma.View;
using MySql.Data.MySqlClient;

namespace SalonLjepoteBelma.ViewModel
{
    class LoginViewModel
    {
        public ICommand Prijava { get; set; }
        public ICommand Registracija { get; set; }

        
        

        string connectionString = "server=localhost;user=root;pwd=;database=salonljepote";
        MySqlConnection con;

        public LoginViewModel()
        {
            Prijava = new RelayCommand(prijava);
            Registracija = new RelayCommand(registracija);
            
            con = new MySqlConnection(connectionString);

        }
        public Action CloseAction { get; set; }

        public void prijava(object parametar)
        {

            if (korisnickoIme == "sef" && sifra=="sef")
            {
                Sef NovaSefForma = new Sef();
                NovaSefForma.Show();
                

            }
            else if (korisnickoIme == "radnik" && sifra == "radnik")
            {
                Radnik NovaRadnikForma = new Radnik();
                NovaRadnikForma.Show();
            }
            else
            {
                IzborUsluge NovaUslugaForma = new IzborUsluge();
                NovaUslugaForma.Show();
            }

        }
        public void registracija(object parametar)
        {
            try
            {
                con.Open();
                //unos korisnika u bazu
                MySqlCommand insertUpit = new MySqlCommand("insert into korisnici(Ime,Prezime,Email,Broj_telefona,Broj_kartice,Korisnicko_ime,Sifra) values('" + ime + "','" + prezime + "','" + email + "','" + brojTelefona + "','" + brojKartice + "','" + korisnickoIme1 + "','" + sifra1 + "')", con);
                insertUpit.ExecuteNonQuery();
            }
            catch (Exception) { }
            finally
            {
                con.Close();
            }

            IzborUsluge NovaUslugaForma = new IzborUsluge();
            NovaUslugaForma.Show();

        }
        
        private String korisnickoIme;

        public String KorisnickoIme
        {
            get { return korisnickoIme; }
            set { korisnickoIme = value; }
        }
        private String sifra;

        public String Sifra
        {
            get { return sifra; }
            set { sifra = value; }
        }
        private String korisnickoIme1;

        public String KorisnickoIme1
        {
            get { return korisnickoIme1; }
            set { korisnickoIme1 = value; }
        }
        private String sifra1;

        public String Sifra1
        {
            get { return sifra1; }
            set { sifra1 = value; }
        }
        private string ime;

        public string Ime
        {
            get { return ime; }
            set { ime = value; }
        }
        private string prezime;

        public string Prezime
        {
            get { return prezime; }
            set { prezime = value; }
        }
        private string email;

        public string Email
        {
            get { return email; }
            set { email = value; }
        }
        private int brojTelefona;

        public int BrojTelefona
        {
            get { return brojTelefona; }
            set { brojTelefona = value; }
        }
        private int brojKartice;

        public int BrojKartice
        {
            get { return brojKartice; }
            set { brojKartice = value; }
        }


    

    }
}
