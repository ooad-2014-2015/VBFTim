﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using SalonLjepoteBelma.View;
using MySql.Data.MySqlClient;
using System.Collections.ObjectModel;
using SalonLjepoteBelma.Models;
using System.Windows;

namespace SalonLjepoteBelma.ViewModel
{
    public class RezervacijaViewModel
    {
        public ICommand ZavrsiRezervaciju { get; set; }

        string connectionString = "server=localhost;user=root;pwd=;database=salonljepote";
        MySqlConnection con;

        private ObservableCollection<Raspored> lista;

        public ObservableCollection<Raspored> Lista
        {
            get { return lista; }
            set { lista = value; }
        }

        public RezervacijaViewModel()
        {
           

            ZavrsiRezervaciju = new RelayCommand(zavrsiRezervaciju);
            con = new MySqlConnection(connectionString);
            try
            {
                con.Open();
                MySqlCommand upitKomanda = new MySqlCommand("select * from raspored", con);
                MySqlDataReader r = upitKomanda.ExecuteReader();
                lista = new ObservableCollection<Raspored>();
                while (r.Read())
                {
                    Raspored ras = new Raspored(r.GetString("Ponedjeljak"), r.GetString("Utorak"), r.GetString("Srijeda"), r.GetString("Cetvrtak"), r.GetString("Petak"));
                    lista.Add(ras);

                }
                r.Close();
            }
            catch (Exception) { }
           
            
        }
        public void zavrsiRezervaciju(object parameter)
        {
            
            try
            {
                
                MySqlCommand insertUpit = new MySqlCommand("insert into transakcije(Dan,Vrijeme) values('" + dan + "','" + vrijeme + "')", con);
                insertUpit.ExecuteNonQuery();

                MySqlCommand zadnjiRed = new MySqlCommand("select ID from transakcije",con);
                MySqlDataReader zadnji = zadnjiRed.ExecuteReader();
                while (zadnji.Read())
                {
                    zad = zadnji.GetInt32("ID");
                }
                zadnji.Close();
                

            }
            catch (Exception) { }
            finally
            {
                con.Close();
            }
            MessageBoxResult result = MessageBox.Show("Uspjesno ste izvrsili rezervaciju,ID vase rezervacije je "+zad+" ,mozete ga iskoristiti da pristupite mobilnoj aplikacije i vidite detalje vase rezervacije. Ako zelite zatvoriti aplikaciju kliknite YES,ako zelite novu rezervaciju kliknite CANCEL,ako zelite da se odjavite kliknite NO", "Rezervacija", MessageBoxButton.YesNoCancel);


            switch (result)
            {
                case MessageBoxResult.Yes:
                    App.Current.Shutdown();
                    break;
                case MessageBoxResult.No:
                    MainWindow mw = new MainWindow();
                    mw.Show();
                    break;
                case MessageBoxResult.Cancel:
                    IzborUsluge iu = new IzborUsluge();
                    iu.Show();
                    break;
            }
            
        }
        
        public Action CloseAction { get; set; }

        private String dan;

        public String Dan
        {
            get { return dan; }
            set { dan = value; }
        }
        private String vrijeme;

        public String Vrijeme
        {
            get { return vrijeme; }
            set { vrijeme = value; }
        }
        private Int32 zad;

        public Int32 Zad
        {
            get { return zad; }
            set { zad = value; }
        }
  
       
       
      
    }
}
