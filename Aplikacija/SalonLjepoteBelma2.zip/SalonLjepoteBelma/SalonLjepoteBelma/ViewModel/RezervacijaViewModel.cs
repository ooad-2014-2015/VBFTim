﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using SalonLjepoteBelma.View;

namespace SalonLjepoteBelma.ViewModel
{
    public class RezervacijaViewModel
    {
        public ICommand ZavrsiRezervaciju { get; set; }
        
        
        public RezervacijaViewModel()
        {   

            
            ZavrsiRezervaciju = new RelayCommand(zavrsiRezervaciju);
            
        }
        public void zavrsiRezervaciju(object parameter)
        {
            Kraj novaKraj = new Kraj();
            novaKraj.Show();
        }
        public Action CloseAction { get; set; }
       

       
      
    }
}
