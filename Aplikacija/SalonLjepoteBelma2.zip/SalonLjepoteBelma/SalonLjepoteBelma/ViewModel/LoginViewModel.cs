﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using SalonLjepoteBelma.View;

namespace SalonLjepoteBelma.ViewModel
{
    class LoginViewModel
    {
        public ICommand Prijava { get; set; }
        public ICommand Registracija { get; set; }


        public LoginViewModel()
        {
            Prijava = new RelayCommand(prijava);
            Registracija = new RelayCommand(registracija);

        }
        public Action CloseAction { get; set; }

        public void prijava(object parametar)
        {

            if (korisnickoIme == "sef" && sifra=="sef")
            {
                Sef NovaSefForma = new Sef();
                NovaSefForma.Show();
                

            }
            else if (korisnickoIme == "radnik" && sifra == "radnik")
            {
                Radnik NovaRadnikForma = new Radnik();
                NovaRadnikForma.Show();
            }
            else
            {
                IzborUsluge NovaUslugaForma = new IzborUsluge();
                NovaUslugaForma.Show();
            }

        }
        public void registracija(object parametar)
        {
            IzborUsluge NovaUslugaForma = new IzborUsluge();
            NovaUslugaForma.Show();
        }
        
        private String korisnickoIme;

        public String KorisnickoIme
        {
            get { return korisnickoIme; }
            set { korisnickoIme = value; }
        }
        private String sifra;

        public String Sifra
        {
            get { return sifra; }
            set { sifra = value; }
        }


    

    }
}
