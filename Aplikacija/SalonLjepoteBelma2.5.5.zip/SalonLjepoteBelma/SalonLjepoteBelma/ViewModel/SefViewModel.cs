﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Collections.ObjectModel;
using SalonLjepoteBelma.Models;
using System.ComponentModel;
using System.Windows.Input;
using System.Windows;
using SalonLjepoteBelma.View;


namespace SalonLjepoteBelma.ViewModel
{
   public class SefViewModel:INotifyPropertyChanged
    {
  
       string connectionString = "server=localhost;user=root;pwd=;database=salonljepote";
        MySqlConnection con;

        private ObservableCollection<Zaposleni> listaZaposleni;

        public ObservableCollection<Zaposleni> ListaZaposleni
        {
            get { return listaZaposleni; }
            set { listaZaposleni = value; OnPropertyChanged("ListaZaposleni"); }
        }
        private ObservableCollection<Transkacije> listaTransakcija;

        public ObservableCollection<Transkacije> ListaTransakcija
        {
            get { return listaTransakcija; }
            set { listaTransakcija = value; OnPropertyChanged("ListaTransakcija"); }
        }
        private string idBrisanje;

        public string IdBrisanje
        {
            get { return idBrisanje; }
            set { idBrisanje = value; }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }

        }
        public ICommand Obrisi { get; set; }
        public ICommand Dodaj { get; set; }
        public ICommand Izlaz { get; set; }
       //sef pomocna
        public ICommand DodajBaza { get; set; }
        public ICommand PrintajIzvjestaj { get; set; }



        public SefViewModel()
        {
            Dodaj= new RelayCommand(dodaj);
            Obrisi = new RelayCommand(obrisi);
            Izlaz = new RelayCommand(izlaz);

            DodajBaza = new RelayCommand(dodajBaza);
            PrintajIzvjestaj = new RelayCommand(printajIzvjestaj);

            con = new MySqlConnection(connectionString);
            try
            {
                con.Open();
            }
            catch (Exception) { }

            try
            {

                MySqlCommand upitKomanda2 = new MySqlCommand("select ID_zaposlenog,Ime,Plata,Datum_zaposlenja,Veza_odjel from zaposleni", con);
                MySqlDataReader b = upitKomanda2.ExecuteReader();
                listaZaposleni = new ObservableCollection<Zaposleni>();
                while (b.Read())
                {
                    Zaposleni z = new Zaposleni(b.GetString("ID_zaposlenog"), b.GetString("Ime"), b.GetInt32("Plata"), b.GetDateTime("Datum_zaposlenja"), b.GetInt32("Veza_odjel"));
                    listaZaposleni.Add(z);

                }
                b.Close();

            }
            catch (Exception) { }
           
             try
            {

                MySqlCommand upitKomanda1 = new MySqlCommand("select Ime_Zaposlenog,Cijena_Usluge,Dan,Vrijeme from transakcije", con);
                MySqlDataReader a = upitKomanda1.ExecuteReader();
                listaTransakcija = new ObservableCollection<Transkacije>();
                while (a.Read())
                {
                    Transkacije t = new Transkacije(a.GetString("Ime_Zaposlenog"), a.GetInt32("Cijena_Usluge"), a.GetString("Dan"), a.GetString("Vrijeme"));
                    listaTransakcija.Add(t);

                }
                a.Close();

            }
            catch (Exception) { }
            
           
        }
        private void obrisi(object parameter)
        {
            try
            {
                MySqlCommand deleteUpit = new MySqlCommand("delete from zaposleni where ID_zaposlenog='" + IdBrisanje + "'", con);
                deleteUpit.ExecuteNonQuery();

                MessageBoxResult result = MessageBox.Show("Uspjesno ste obrisali radnik iz baze podataka", "Radnik brisanje", MessageBoxButton.OK);
                switch (result)
                {
                    case MessageBoxResult.OK:
                        Sef r = new Sef();
                        r.Show();
                        break;
                }

            }
            catch (Exception) { }

        }
        private void dodaj(object parameter)
        {
            SefPomocna sp = new SefPomocna();
            sp.Show();
        }
        private void izlaz(object parameter)
        {
            MessageBoxResult result = MessageBox.Show("Ako zelite zatvoriti aplikaciju kliknite YES,ako zelite ponovo azurirati ili brisati kliknite CANCEL,ako zelite da se odjavite kliknite NO", "Radnik Odjava", MessageBoxButton.YesNoCancel);


            switch (result)
            {
                case MessageBoxResult.Yes:
                    App.Current.Shutdown();
                    break;
                case MessageBoxResult.No:
                    LoginView mw = new LoginView();
                    mw.Show();
                    break;
                case MessageBoxResult.Cancel:
                    Sef iu = new Sef();
                    iu.Show();
                    break;
            }
        }
        private void dodajBaza(object parameter)
        {

         
                //unos korisnika u bazu
            try
            {
                MySqlCommand insertUpit = new MySqlCommand("insert into zaposleni(ID_zaposlenog,Ime,Plata,Datum_zaposlenja,Veza_odjel) values('" + idTx + "','" + imeTx + "','" + plataTx + "','" + datumTx + "','" + odjelTx + "')", con);
                insertUpit.ExecuteNonQuery();



                MessageBoxResult result = MessageBox.Show("Uspjesno ste dodali radnika,za novo dodavanje kliknite OK, u suprotnom CANCEL da se vratite na glavnu formu", "Radnik dodaj", MessageBoxButton.OKCancel);
                switch (result)
                {
                    case MessageBoxResult.OK:
                        SefPomocna sp = new SefPomocna();
                        sp.Show();
                        break;
                    case MessageBoxResult.Cancel:
                        Sef rk = new Sef();
                        rk.Show();
                        break;
                }
            }
            catch (Exception) { }
            finally
            {
                con.Close();
            }
         
        }
        private void printajIzvjestaj(object parameter)
        {
            //Belaj
       
        }
        private string idTx;

        public string IdTx
        {
            get { return idTx; }
            set { idTx = value; }
        }
        private string imeTx;

        public string ImeTx
        {
            get { return imeTx; }
            set { imeTx = value; }
        }
        private DateTime datumTx;

        public DateTime DatumTx
        {
            get { return datumTx; }
            set { datumTx = value; }
        }
        private int plataTx;

        public int PlataTx
        {
            get { return plataTx; }
            set { plataTx = value; }
        }
        private int odjelTx;

        public int OdjelTx
        {
            get { return odjelTx; }
            set { odjelTx = value; }
        }
        private int posaoTx;

        public int PosaoTx
        {
            get { return posaoTx; }
            set { posaoTx = value; }
        }


    }
}

