﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SalonLjepoteBelma.View
{
    /// <summary>
    /// Interaction logic for Rezervacija.xaml
    /// </summary>
    public partial class Rezervacija : Window
    {
        public Rezervacija()
        {
            InitializeComponent();
            this.Deactivated += new EventHandler(Window1_Deactivated);
        }

        void Window1_Deactivated(object sender, EventArgs e)
        {
            Visibility = Visibility.Collapsed;
        }
    }
}
