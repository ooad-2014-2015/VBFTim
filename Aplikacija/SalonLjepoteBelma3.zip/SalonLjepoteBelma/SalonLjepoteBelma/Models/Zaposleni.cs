﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalonLjepoteBelma.Models
{
   public class Zaposleni
    {
        private string imePrezime;

        public string ImePrezime
        {
            get { return imePrezime; }
            set { imePrezime = value; }
        }

        public Zaposleni(string naziv)
        {
            imePrezime = naziv;            
        }
    }
}
