﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Collections.ObjectModel;
using SalonLjepoteBelma.Models;
using System.ComponentModel;
using System.Windows.Input;
using System.Windows;


namespace SalonLjepoteBelma.ViewModel
{
    class RadnikViewModel:INotifyPropertyChanged
    {   
     
        string connectionString = "server=localhost;user=root;pwd=;database=salonljepote";
        MySqlConnection con;

        private string imeBrisanje;

        public string ImeBrisanje
        {
            get { return imeBrisanje; }
            set { imeBrisanje = value; }
        }
        private ObservableCollection<Korisnik> listaIme;

        public ObservableCollection<Korisnik> ListaIme
        {
            get { return listaIme; }
            set { listaIme = value; OnPropertyChanged("ListaIme"); }
        }
        public ICommand Obrisi { get; set; }
        
        public RadnikViewModel()
        {
            Obrisi = new RelayCommand(obrisi);
            con = new MySqlConnection(connectionString);
               try
               {
                con.Open();
                MySqlCommand upitKomanda = new MySqlCommand("select * from korisnici", con);
                MySqlDataReader r = upitKomanda.ExecuteReader();
                listaIme = new ObservableCollection<Korisnik>();
                while (r.Read())
                {
                    Korisnik k = new Korisnik(r.GetString("Ime"), r.GetString("Prezime"), r.GetString("Email"), r.GetInt32("Broj_telefona"), r.GetInt32("Broj_kartice"), r.GetString("Korisnicko_ime"), r.GetString("Sifra"));
                    listaIme.Add(k);

                }
                r.Close();
               }
            catch(Exception){}

            
        }
        
        private void obrisi(object parameter)
        {
            try
            {
                MySqlCommand deleteUpit = new MySqlCommand("delete from korisnici where Korisnicko_ime='" + imeBrisanje + "'", con);
                deleteUpit.ExecuteNonQuery();
                
                MessageBox.Show("Uspjesno ste obrisali korisnika iz baze podataka");
            }
            catch (Exception) { }
            finally
            {
                con.Close();
            }
            
        }
        //ovo mescini ne radi
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName)
       {
         if (PropertyChanged != null)
        {
         PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

       }
    
       

        

       
    }
}
