﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SalonLjepoteBelma.Models;
using System.Windows.Input;
using SalonLjepoteBelma.View;

namespace SalonLjepoteBelma.ViewModel
{
    class UslugeViewModel
    {
        
        private List<Zaposleni> noviZaposleni;

        public List<Zaposleni> NoviZaposleni
        {
            get { return noviZaposleni; }
            set { noviZaposleni = value; }
        }

        private List<PosloviModel> noviPoslovi;

        public List<PosloviModel> NoviPoslovi
        {
            get { return noviPoslovi; }
            set { noviPoslovi = value; }
        }
        public ICommand UnosSvega { get; set; }

        private List<PosloviModel> noviPoslovi1;

        public List<PosloviModel> NoviPoslovi1
        {
            get { return noviPoslovi1; }
            set { noviPoslovi1 = value; }
        }
        private List<Zaposleni> noviZaposleni1;

        public List<Zaposleni> NoviZaposleni1
        {
            get { return noviZaposleni1; }
            set { noviZaposleni1 = value; }
        }
        private List<Zaposleni> noviZaposleni2;

        public List<Zaposleni> NoviZaposleni2
        {
            get { return noviZaposleni2; }
            set { noviZaposleni2 = value; }
        }
        private List<Zaposleni> noviZaposleni3;

        public List<Zaposleni> NoviZaposleni3
        {
            get { return noviZaposleni3; }
            set { noviZaposleni3 = value; }
        }
        private List<PosloviModel> noviPoslovi2;

        public List<PosloviModel> NoviPoslovi2
        {
            get { return noviPoslovi2; }
            set { noviPoslovi2 = value; }
        }
        private List<PosloviModel> noviPoslovi3;

        public List<PosloviModel> NoviPoslovi3
        {
            get { return noviPoslovi3; }
            set { noviPoslovi3 = value; }
        }

        private List<String> listaUsluga;

        public List<String> ListaUsluga
        {
            get { return listaUsluga; }
            set { listaUsluga = value; }
        }
        
        
        public UslugeViewModel ()
        {
            UnosSvega = new RelayCommand(unosSvega);

           
            noviZaposleni = new List<Zaposleni>();
            noviPoslovi = new List<PosloviModel>();


            noviZaposleni1 = new List<Zaposleni>();
            noviPoslovi1 = new List<PosloviModel>();


            noviZaposleni2 = new List<Zaposleni>();
            noviPoslovi2 = new List<PosloviModel>();


            noviZaposleni3 = new List<Zaposleni>();
            noviPoslovi3 = new List<PosloviModel>();

            listaUsluga = new List<String>();
            listaUsluga.Add("Njega lica");
            listaUsluga.Add("Njega tijela");
            listaUsluga.Add("Manikir/Pedikir");
            listaUsluga.Add("Frizerske usluge");

            //Njega lica
            PosloviModel p1 = new PosloviModel("Tretman za suhu kozu", 25);
            PosloviModel p2 = new PosloviModel("Tretman za masnu kozu", 30);
            PosloviModel p3 = new PosloviModel("Tretman za osjetljivu kozu", 30);
            PosloviModel p4 = new PosloviModel("Tretman za muskarce", 20);

            noviPoslovi.Add(p1);
            noviPoslovi.Add(p2);
            noviPoslovi.Add(p3);
            noviPoslovi.Add(p4);

            Zaposleni z1 = new Zaposleni("Zaposlenik njega lica1");
            Zaposleni z2 = new Zaposleni("Zaposlenik njega lica2");

            noviZaposleni.Add(z1);
            noviZaposleni.Add(z2);

            //Njega tijela
            PosloviModel p5 = new PosloviModel("Depilacija", 15);
            PosloviModel p6 = new PosloviModel("Masaza", 25);
            PosloviModel p7 = new PosloviModel("Kupka", 40);
            PosloviModel p8 = new PosloviModel("Piling tijela", 20);

            noviPoslovi1.Add(p5);
            noviPoslovi1.Add(p6);
            noviPoslovi1.Add(p7);
            noviPoslovi1.Add(p8);

            Zaposleni z3 = new Zaposleni("Zaposlenik njega tijela1");
            Zaposleni z4 = new Zaposleni("Zaposlenik njega tijela2");

            noviZaposleni1.Add(z3);
            noviZaposleni1.Add(z4);
            //Manikir/Pedikir
            PosloviModel p9 = new PosloviModel("Manikir", 15);
            PosloviModel p10 = new PosloviModel("Pedikir", 25);
            PosloviModel p11 = new PosloviModel("Nail art", 40);
           

            noviPoslovi2.Add(p9);
            noviPoslovi2.Add(p10);
            noviPoslovi2.Add(p11);

            Zaposleni z5 = new Zaposleni("Zaposlenik manikir1");
            Zaposleni z6 = new Zaposleni("Zaposlenik manikir2");

            noviZaposleni2.Add(z5);
            noviZaposleni2.Add(z6);
            //Frizerske usluge
            PosloviModel p12 = new PosloviModel("Musko sisanje", 7);
            PosloviModel p13 = new PosloviModel("Zensko sisanje", 15);
            PosloviModel p14 = new PosloviModel("Svecane frizure", 30);
            PosloviModel p15 = new PosloviModel("Nadogradnja kose", 45);

            noviPoslovi3.Add(p12);
            noviPoslovi3.Add(p13);
            noviPoslovi3.Add(p14);
            noviPoslovi3.Add(p15);

            Zaposleni z7 = new Zaposleni("Zaposlenik frizerske usluge1");
            Zaposleni z8 = new Zaposleni("Zaposlenik frizerske usluge2");

            noviZaposleni3.Add(z7);
            noviZaposleni3.Add(z8);

         
        }
         public Action CloseAction { get; set; }

         public void unosSvega(object parametar)
         {
             if (textbox1 == "Njega lica")
             {
                 Usluge u = new Usluge();
                 u.Show();

             }
             if (textbox1 == "Njega tijela")
             {

                 NjegaTijela t = new NjegaTijela();
                 t.Show();
             }
             if (textbox1 == "Manikir/Pedikir")
             {
                 ManikirPedikir mp = new ManikirPedikir();
                 mp.Show();
             }
             if (textbox1 == "Frizerske usluge") 
             {
                 FrizerskeUsluge fu = new FrizerskeUsluge();
                 fu.Show();
             }
         }
         private String textbox1;

         public String Textbox1
         {
             get { return textbox1; }
             set { textbox1 = value; }
         }

       
        
    }
}
