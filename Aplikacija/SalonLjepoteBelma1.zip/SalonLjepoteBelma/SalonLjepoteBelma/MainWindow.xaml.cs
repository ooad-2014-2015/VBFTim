﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SalonLjepoteBelma.ViewModel;



namespace SalonLjepoteBelma
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            
        }
        //Njega lica
        private void njega_lica(object sender, RoutedEventArgs e)
        {
            // Get TextBlock reference.
            var block = sender as TextBlock;
            // Set text.
            block.Text = "Tretman lica je kozmetički postupak koji uključuje nekoliko radnji, kao što su: čišćenje lica , uklanjanje mrtvih stanica, pranje, masaža, peeling i slično."
            + "Na temelju analize, kozmetičar će upotrijebiti proizvode posebno prilagođene Vama.";
            }
        //Njega tijela
        private void njega_tijela(object sender, RoutedEventArgs e)
        {
            // Get TextBlock reference.
            var block = sender as TextBlock;
            // Set text.
            block.Text = " Njega tijela pomaže nam da što dulje zadržimo ljepotu i mladenački izgled, ali i da se osjećamo ženstvenije."
            +"Služi nam i kao dobar izgovor da odvojimo malo vremena samo za sebe..., a ponekad baš ta prirodna njega može biti i jako, jako zabavna"; 
        }
        //Manikir pedikir
        private void manikir_pedikir(object sender, RoutedEventArgs e)
        {
            // Get TextBlock reference.
            var block = sender as TextBlock;
            // Set text.
            block.Text = "Ukras lijepih ruku su njegovani nokti. Pogrešno je mišljenje da se njega noktiju sastoji samo u lakiranju."
            + "Njega noktiju obavezna je. Svaka žena želi izgledati lijepo i privlačno, a to nikako nije moguće imate li nekvalitetne nokte.";
        }
        //Frizerske usluge
        private void frizerske_usluge(object sender, RoutedEventArgs e)
        {
            // Get TextBlock reference.
            var block = sender as TextBlock;
            // Set text.
            block.Text = "Šišanje kose je jedna od prirodnih potreba ljudskog tela."
            + "Kosa je rožnata tvorevina kože koja konstatno raste i obnavlja se te je s vremena na vreme neophodno skraćivati i šišati."
            + "Šišanje kose nije samo potreba to je često i pitanje izgleda.";
        }
        //O nama
        private void o_nama(object sender, RoutedEventArgs e)
        {
            // Get TextBlock reference.
            var block = sender as TextBlock;
            // Set text.
            block.Text = "Ljepota podrazumijeva pravilan način života te korištenje pravih kozmetičkih preparata." 
                +"Salon ljepote Belma nudi prave ponude za istinski osjećaj ljepote i relaksacije. ";
        }
        

    }
}
