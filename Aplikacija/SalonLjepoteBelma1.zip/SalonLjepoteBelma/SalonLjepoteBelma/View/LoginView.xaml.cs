﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using SalonLjepoteBelma.ViewModel;

namespace SalonLjepoteBelma.View
{
    /// <summary>
    /// Interaction logic for LoginView.xaml
    /// </summary>
    public partial class LoginView : Window
    {
       
        public LoginView()
        {
            InitializeComponent();
            
        }
        //ima fokus na korisnicko ime
       /* public void KorisnickoImeGot(object sender, RoutedEventArgs e)
        {   
            if(korisnickoIme.Text=="Korisnicko ime")
            korisnickoIme.Text = string.Empty;
            
        }
        //nema fokus na korisnicko ime
        public void KorisnickoImeLost(object sender, RoutedEventArgs e)
        {
            if(korisnickoIme.Text == string.Empty)
                korisnickoIme.Text="Korisnicko ime";
            
        }*/
        
        
        
    }
}
