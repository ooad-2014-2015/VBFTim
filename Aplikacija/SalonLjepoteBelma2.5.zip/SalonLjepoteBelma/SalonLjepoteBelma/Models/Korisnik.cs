﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalonLjepoteBelma.Models
{
    class Korisnik
    {
        private string ime;

        public string Ime
        {
            get { return ime; }
            set { ime = value; }
        }
        private string prezime;

        public string Prezime
        {
            get { return prezime; }
            set { prezime = value; }
        }
        private string email;

        public string Email
        {
            get { return email; }
            set { email = value; }
        }
        private int brojTelefona;

        public int BrojTelefona
        {
            get { return brojTelefona; }
            set { brojTelefona = value; }
        }
        private int brojKartice;

        public int BrojKartice
        {
            get { return brojKartice; }
            set { brojKartice = value; }
        }
        private string korisnickoIme;

        public string KorisnickoIme
        {
            get { return korisnickoIme; }
            set { korisnickoIme = value; }
        }
        private string sifra;

        public string Sifra
        {
            get { return sifra; }
            set { sifra = value; }
        }
        public Korisnik(string imee, string prezimee, string emaill, int brTel, int brKar, string username, string pass)
        {
            ime = imee;
            prezime = prezimee;
            email = emaill;
            brojTelefona = brTel;
            brojKartice = brKar;
            korisnickoIme = username;
            sifra = pass;

        }
    }
}
