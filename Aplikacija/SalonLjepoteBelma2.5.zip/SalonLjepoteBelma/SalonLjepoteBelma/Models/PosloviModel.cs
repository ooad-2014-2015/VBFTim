﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalonLjepoteBelma.Models
{
  public  class PosloviModel
    {
        private string nazivPosla;

        public string NazivPosla
        {
            get { return nazivPosla; }
            set { nazivPosla = value; }
        }

        private int cijenaPosla;

        public int CijenaPosla
        {
            get { return cijenaPosla; }
            set { cijenaPosla = value; }
        }

        public PosloviModel(string naziv, int cijena)
        {
            nazivPosla = naziv;
            cijenaPosla = cijena;
        }
    }
}
