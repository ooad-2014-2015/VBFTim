﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
namespace SalonLjepoteBelma.Pristup_bazi
{
    class Baza
    {   
       /*
        static void Main(string[] args)
        {
            string username = "root";
            string password = "";
            string db = "salonljepote";

            string connectionString = "server=localhost;user=" + username + ";pwd=" + password + ";database=" + db;
            MySqlConnection con = new MySqlConnection(connectionString);
            try
            {
                
                con.Open();


            }
            catch (Exception)
            {
            }
            finally
            {
                con.Close();
            }
        }*/
      
      
    }
}
