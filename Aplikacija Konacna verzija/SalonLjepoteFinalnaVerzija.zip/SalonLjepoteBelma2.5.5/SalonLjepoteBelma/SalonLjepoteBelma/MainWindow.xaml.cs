﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SalonLjepoteBelma.ViewModel;
using System.Diagnostics;
using System.IO;



namespace SalonLjepoteBelma
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            
        }

        private void imageBon_MouseLeftButtonDown_1(object sender, MouseButtonEventArgs e)
        {
            MessageBox.Show("Poruka o bonovima");
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            string path = "filename.txt";
            
            if (File.Exists(path))
            {
                Process.Start(new ProcessStartInfo(path));
            }
            
           

        }

        
        /* poziva se sa Loaded
        private void njega_lica(object sender, RoutedEventArgs e)
        {
            // Get TextBlock reference.
            var block = sender as TextBlock;
            // Set text.
            block.Text = "Tretman lica je kozmetički postupak koji uključuje nekoliko radnji, kao što su: čišćenje lica , uklanjanje mrtvih stanica, pranje, masaža, peeling i slično."
            + "Na temelju analize, kozmetičar će upotrijebiti proizvode posebno prilagođene Vama.";
            }
       */
        

    }
}
