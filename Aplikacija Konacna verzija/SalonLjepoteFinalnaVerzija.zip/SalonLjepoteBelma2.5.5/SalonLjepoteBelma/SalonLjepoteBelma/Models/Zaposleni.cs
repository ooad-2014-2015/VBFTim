﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalonLjepoteBelma.Models
{
   public class Zaposleni
    {
        private string imePrezime;

        public string ImePrezime
        {
            get { return imePrezime; }
            set { imePrezime = value; }
        }


        public Zaposleni(string naziv)
        {
            imePrezime = naziv;            
        }
        private Int32 plata;

        public Int32 Plata
        {
            get { return plata; }
            set { plata = value; }
        }
      
       
        private int idOdjela;

        public int IdOdjela
        {
            get { return idOdjela; }
            set { idOdjela = value; }
        }
        public Zaposleni(string i,string ime, Int32 pl, int idO)
        {
            imePrezime = ime;
            plata = pl;
            idOdjela = idO;
            id = i;
        }
        private string id;

        public string Id
        {
            get { return id; }
            set { id = value; }
        }
    }
}
