﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalonLjepoteBelma.Models
{
    public class Transkacije
    {
        private string ime;

        public string Ime
        {
            get { return ime; }
            set { ime = value; }
        }
        private string cijenaUsluge;

        public string CijenaUsluge
        {
            get { return cijenaUsluge; }
            set { cijenaUsluge = value; }
        }
        private string dan;

        public string Dan
        {
            get { return dan; }
            set { dan = value; }
        }
        private string vrijeme;

        public string Vrijeme
        {
            get { return vrijeme; }
            set { vrijeme = value; }
        }

        public Transkacije(string p1, string p2, string p3, string p4)
        {
            // TODO: Complete member initialization
            this.Ime = p1;
            this.CijenaUsluge = p2;
            this.Dan = p3;
            this.Vrijeme = p4;
        }

    }
}
