﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SalonLjepoteBelma.View
{
    /// <summary>
    /// Interaction logic for Kraj.xaml
    /// </summary>
    public partial class Kraj : Window
    {
        public Kraj()
        {
            InitializeComponent();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            App.Current.Shutdown();//dok ne skontam koju cu klasu i sta, fali ti jos button za povratak nazad, ako bude mogao..
        }
    }
}
