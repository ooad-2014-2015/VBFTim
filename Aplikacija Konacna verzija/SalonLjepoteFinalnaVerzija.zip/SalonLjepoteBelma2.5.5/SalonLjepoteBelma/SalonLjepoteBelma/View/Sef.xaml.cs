﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace SalonLjepoteBelma.View
{
    /// <summary>
    /// Interaction logic for Sef.xaml
    /// </summary>
    public partial class Sef : Window
    {
        public Sef()
        {
            InitializeComponent();

            this.Deactivated += new EventHandler(Window1_Deactivated);
        }

        void Window1_Deactivated(object sender, EventArgs e)
        {
            Visibility = Visibility.Collapsed;
        }
        private string put;

        public string Put
        {
            get { return put; }
            set { put = value; }
        }
        
             
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {   
            //otvaranje prozora za pritanje
            PrintDialog printDialog = new PrintDialog();
            if (printDialog.ShowDialog() == true)
            {
                printDialog.PrintVisual(dataGrid, "My First Print Job");
            }
          
            //Kreiranje excel fajl
            dataGrid.SelectAllCells();
            dataGrid.ClipboardCopyMode = DataGridClipboardCopyMode.IncludeHeader;
            ApplicationCommands.Copy.Execute(null, dataGrid);
            String resultat = (string)Clipboard.GetData(DataFormats.CommaSeparatedValue);
            String result = (string)Clipboard.GetData(DataFormats.Text);
            dataGrid.UnselectAllCells();
            System.IO.StreamWriter file = new System.IO.StreamWriter(@"C:\Users\Fadil\Desktop\test.xls");
            file.WriteLine(result.Replace(',',',' ));
            file.Close();

            MessageBoxResult izlaz = MessageBox.Show("Uspjesno ste isprintali izvjestaj i kreirali excel fajl!","Print/Export", MessageBoxButton.OK);
            switch (izlaz)
            {
                case MessageBoxResult.OK:
                    Sef s = new Sef();
                    s.Show();
                    break;
                
            }
        }


      
       
    }
}
