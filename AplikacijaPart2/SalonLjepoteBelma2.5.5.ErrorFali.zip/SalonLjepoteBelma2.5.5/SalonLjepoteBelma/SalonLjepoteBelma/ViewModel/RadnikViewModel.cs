﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Collections.ObjectModel;
using SalonLjepoteBelma.Models;
using System.ComponentModel;
using System.Windows.Input;
using System.Windows;
using SalonLjepoteBelma.View;


namespace SalonLjepoteBelma.ViewModel
{
    class RadnikViewModel:INotifyPropertyChanged
    {   
     
        string connectionString = "server=localhost;user=root;pwd=;database=salonljepote";
        MySqlConnection con;

        private string imeBrisanje;

        public string ImeBrisanje
        {
            get { return imeBrisanje; }
            set { imeBrisanje = value; }
        }
        private ObservableCollection<Korisnik> listaIme;

        public ObservableCollection<Korisnik> ListaIme
        {
            get { return listaIme; }
            set { listaIme = value; OnPropertyChanged("ListaIme"); }
        }
        public ICommand Obrisi { get; set; }
        public ICommand SpremiIzmjene { get; set; }
        public ICommand Izlaz { get; set; }

        public RadnikViewModel()
        {
            SpremiIzmjene = new RelayCommand(spremiIzmjene);
            Obrisi = new RelayCommand(obrisi);
            Izlaz = new RelayCommand(izlaz);
            con = new MySqlConnection(connectionString);
               try
               {
                con.Open();
                MySqlCommand upitKomanda = new MySqlCommand("select * from korisnici", con);
                MySqlDataReader r = upitKomanda.ExecuteReader();
                listaIme = new ObservableCollection<Korisnik>();
                while (r.Read())
                {
                    Korisnik k = new Korisnik(r.GetString("Ime"), r.GetString("Prezime"), r.GetString("Email"), r.GetInt32("Broj_telefona"), r.GetInt32("Broj_kartice"), r.GetString("Korisnicko_ime"), r.GetString("Sifra"));
                    listaIme.Add(k);

                }
                r.Close();
               }
            catch(Exception){}

            
        }
        
        private void obrisi(object parameter)
        {
            try
            {
                MySqlCommand deleteUpit = new MySqlCommand("delete from korisnici where Korisnicko_ime='" + imeBrisanje + "'", con);
                deleteUpit.ExecuteNonQuery();

                MessageBoxResult result = MessageBox.Show("Uspjesno ste obrisali korisnika iz baze podataka", "Korisnik brisanje", MessageBoxButton.OK);
                switch (result)
                {
                    case MessageBoxResult.OK:
                        Radnik r = new Radnik();
                        r.Show();
                        break;
                }
            }
            catch (Exception) { }
           
            
        }
        //ovo mescini ne radi
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName)
       {
         if (PropertyChanged != null)
        {
         PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

       }
        private void spremiIzmjene(object parameter)
        {
            try
            {
                
                //unos rasporeda u bazu
                //prvi red
                MySqlCommand insertUpit = new MySqlCommand("update raspored set Ponedjeljak='" + t1 + "' where id="+1, con);
                insertUpit.ExecuteNonQuery();
                MySqlCommand insertUpit1 = new MySqlCommand("update raspored set Utorak='" + t2 + "' where id=" + 1, con);
                insertUpit1.ExecuteNonQuery();
                MySqlCommand insertUpit2 = new MySqlCommand("update raspored set Srijeda='" + t3 + "' where id=" + 1, con);
                insertUpit2.ExecuteNonQuery();
                MySqlCommand insertUpit3 = new MySqlCommand("update raspored set Cetvrtak='" + t4 + "' where id=" + 1, con);
                insertUpit3.ExecuteNonQuery();
                MySqlCommand insertUpit4 = new MySqlCommand("update raspored set Petak='" + t5 + "' where id=" + 1, con);
                insertUpit4.ExecuteNonQuery();

                //drugi red

                MySqlCommand insertUpit5 = new MySqlCommand("update raspored set Ponedjeljak='" + t6 + "' where id=" + 2, con);
                insertUpit5.ExecuteNonQuery();
                MySqlCommand insertUpit6 = new MySqlCommand("update raspored set Utorak='" + t7 + "' where id=" + 2, con);
                insertUpit6.ExecuteNonQuery();
                MySqlCommand insertUpit7 = new MySqlCommand("update raspored set Srijeda='" + t8 + "' where id=" + 2, con);
                insertUpit7.ExecuteNonQuery();
                MySqlCommand insertUpit8 = new MySqlCommand("update raspored set Cetvrtak='" + t9 + "' where id=" + 2, con);
                insertUpit8.ExecuteNonQuery();
                MySqlCommand insertUpit9 = new MySqlCommand("update raspored set Petak='" + t10 + "' where id=" + 2, con);
                insertUpit9.ExecuteNonQuery();

                //treci red

                MySqlCommand insertUpit10 = new MySqlCommand("update raspored set Ponedjeljak='" + t11 + "' where id=" + 3, con);
                insertUpit10.ExecuteNonQuery();
                MySqlCommand insertUpit11= new MySqlCommand("update raspored set Utorak='" + t12 + "' where id=" + 3, con);
                insertUpit11.ExecuteNonQuery();
                MySqlCommand insertUpit12 = new MySqlCommand("update raspored set Srijeda='" + t13 + "' where id=" + 3, con);
                insertUpit12.ExecuteNonQuery();
                MySqlCommand insertUpit13 = new MySqlCommand("update raspored set Cetvrtak='" + t14 + "' where id=" + 3, con);
                insertUpit13.ExecuteNonQuery();
                MySqlCommand insertUpit14 = new MySqlCommand("update raspored set Petak='" + t15 + "' where id=" + 3, con);
                insertUpit14.ExecuteNonQuery();

                //cetvrti red

                MySqlCommand insertUpit15 = new MySqlCommand("update raspored set Ponedjeljak='" + t16 + "' where id=" + 4, con);
                insertUpit15.ExecuteNonQuery();
                MySqlCommand insertUpit16 = new MySqlCommand("update raspored set Utorak='" + t17 + "' where id=" + 4, con);
                insertUpit16.ExecuteNonQuery();
                MySqlCommand insertUpit17 = new MySqlCommand("update raspored set Srijeda='" + t18 + "' where id=" + 4, con);
                insertUpit17.ExecuteNonQuery();
                MySqlCommand insertUpit18 = new MySqlCommand("update raspored set Cetvrtak='" + t19 + "' where id=" + 4, con);
                insertUpit18.ExecuteNonQuery();
                MySqlCommand insertUpit19 = new MySqlCommand("update raspored set Petak='" + t20 + "' where id=" + 4, con);
                insertUpit19.ExecuteNonQuery();

                MessageBoxResult result = MessageBox.Show("Uspjesno ste azurirali raspored", "Raspored", MessageBoxButton.OK);
                switch (result)
                {   
                    case MessageBoxResult.OK:
                    Radnik r = new Radnik();
                    r.Show();
                    break;
                }
            }
            catch (Exception) { }
            finally
            {
                con.Close();
            }
        }
        private void izlaz(object parameter)
        {
            MessageBoxResult result = MessageBox.Show("Ako zelite zatvoriti aplikaciju kliknite YES,ako zelite ponovo azurirati ili brisati kliknite CANCEL,ako zelite da se odjavite kliknite NO", "Radnik Odjava", MessageBoxButton.YesNoCancel);


            switch (result)
            {
                case MessageBoxResult.Yes:
                    App.Current.Shutdown();
                    break;
                case MessageBoxResult.No:
                    LoginView mw = new LoginView();
                    mw.Show();
                    break;
                case MessageBoxResult.Cancel:
                    Radnik iu = new Radnik();
                    iu.Show();
                    break;
            }
        }
        private string t1;

        public string T1
        {
            get { return t1; }
            set { t1 = value; }
        }
        private string t2;

        public string T2
        {
            get { return t2; }
            set { t2 = value; }
        }
        private string t3;

        public string T3
        {
            get { return t3; }
            set { t3 = value; }
        }
        private string t4;

        public string T4
        {
            get { return t4; }
            set { t4 = value; }
        }
        private string t5;

        public string T5
        {
            get { return t5; }
            set { t5 = value; }
        }
        private string t6;

        public string T6
        {
            get { return t6; }
            set { t6 = value; }
        }
        private string t7;

        public string T7
        {
            get { return t7; }
            set { t7 = value; }
        }
        private string t8;

        public string T8
        {
            get { return t8; }
            set { t8 = value; }
        }
        private string t9;

        public string T9
        {
            get { return t9; }
            set { t9 = value; }
        }
        private string t10;

        public string T10
        {
            get { return t10; }
            set { t10 = value; }
        }
        private string t11;

        public string T11
        {
            get { return t11; }
            set { t11 = value; }
        }
        private string t12;

        public string T12
        {
            get { return t12; }
            set { t12 = value; }
        }
        private string t13;

        public string T13
        {
            get { return t13; }
            set { t13 = value; }
        }
        private string t14;

        public string T14
        {
            get { return t14; }
            set { t14 = value; }
        }
        private string t15;

        public string T15
        {
            get { return t15; }
            set { t15 = value; }
        }
        private string t16;

        public string T16
        {
            get { return t16; }
            set { t16 = value; }
        }
        private string t17;

        public string T17
        {
            get { return t17; }
            set { t17 = value; }
        }
        private string t18;

        public string T18
        {
            get { return t18; }
            set { t18 = value; }
        }
        private string t19;

        public string T19
        {
            get { return t19; }
            set { t19 = value; }
        }
        private string t20;

        public string T20
        {
            get { return t20; }
            set { t20 = value; }
        }
        

       
    }
}
