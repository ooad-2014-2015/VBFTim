﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Threading;


namespace SalonLjepoteBelma.View
{
    /// <summary>
    /// Interaction logic for Usluge.xaml
    /// </summary>
    public partial class Usluge : Window
    {
        
        
        public Usluge()
        {
            InitializeComponent();
            this.Deactivated += new EventHandler(Window1_Deactivated);
            
           
            
            
        }

        void Window1_Deactivated(object sender, EventArgs e)
        {
            Visibility = Visibility.Collapsed;
        }
     

        private void ListBox_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {
                /*string selected = listBox1.SelectedItem.ToString();
                if (selected == "Njega tijela")
                    checkBox1.Content = "";*/
        }


        Thread nit;
        Thread nit1;
        Thread nit2;

        private void checkBox1_Checked(object sender, RoutedEventArgs e)
        {
            
            labela1 = Int32.Parse(label1.Content.ToString());
            ukupno = labela1 + labela2 + labela3 + labela4;
            
        }

        private void checkBox2_Checked(object sender, RoutedEventArgs e)
        {
            
            labela2 = Int32.Parse(label2.Content.ToString());
            ukupno = labela1 + labela2 + labela3 + labela4;
        }
        private void checkBox3_Checked(object sender, RoutedEventArgs e)
        {
           
            labela3 = Int32.Parse(label3.Content.ToString());
            ukupno = labela1 + labela2 + labela3 + labela4;
        }

        private void checkBox4_Checked(object sender, RoutedEventArgs e)
        {
            
            labela4 = Int32.Parse(label4.Content.ToString());
            ukupno = labela1 + labela2 + labela3 + labela4;
        }
        private void checkBox1_Unchecked(object sender, RoutedEventArgs e)
        {
            labela1 = 0;
            ukupno = labela1 + labela2 + labela3 + labela4;
        }
        private void checkBox2_Unchecked(object sender, RoutedEventArgs e)
        {
            labela2 = 0;
            ukupno = labela1 + labela2 + labela3 + labela4;
        }

        private void checkBox3_Unchecked(object sender, RoutedEventArgs e)
        {
            labela3 = 0;
            ukupno = labela1 + labela2 + labela3 + labela4;
        }

        private void checkBox4_Unchecked(object sender, RoutedEventArgs e)
        {
            labela4 = 0;
            ukupno = labela1 + labela2 + labela3 + labela4;
        }

        private int labela1;

        public int Labela1
        {
            get { return labela1; }
            set { labela1 = value; }
        }
        private int labela2;

        public int Labela2
        {
            get { return labela2; }
            set { labela2 = value; }
        }
        private int labela3;

        public int Labela3
        {
            get { return labela3; }
            set { labela3 = value; }
        }
        private int labela4;

        public int Labela4
        {
            get { return labela4; }
            set { labela4 = value; }
        }
        private double ukupno;

        public double Ukupno
        {
            get { return ukupno; }
            set { ukupno = value; }
        }

        private double zlatnaKartica;

        public double ZlatnaKartica
        {
            get { return zlatnaKartica; }
            set { zlatnaKartica = value; }
        }
        private double srebrenaKartica;

        public double SrebrenaKartica
        {
            get { return srebrenaKartica; }
            set { srebrenaKartica = value; }
        }

      
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            labelUkupno.Content = ukupno;
        }
        void izracunaj()
        {
            this.Dispatcher.Invoke((Action)(() =>
            {
                ukupno = labela1 + labela2 + labela3 + labela4;
            }));

        }
        void izracunaj2()
        {
            this.Dispatcher.Invoke((Action)(() =>
            {
                ukupno = ukupno - ukupno * 0.05; ;
            }));

        }
        void izracunaj1()
        {
            this.Dispatcher.Invoke((Action)(() =>
            {
                ukupno = ukupno - ukupno * 0.15; 
                
            }));

        }

        private void zlatna_Checked(object sender, RoutedEventArgs e)
        {
            nit1 = new Thread(new ThreadStart(izracunaj1));
            nit1.Start();
            
        }
        private void Srebrena_Checked(object sender, RoutedEventArgs e)
        {
            nit2 = new Thread(new ThreadStart(izracunaj2));
            nit2.Start();
            
        }

        private void bez_Checked(object sender, RoutedEventArgs e)
        {
            nit = new Thread(new ThreadStart(izracunaj));
            nit.Start();
            
        }

        private void zlatna_Unchecked(object sender, RoutedEventArgs e)
        {
            if (ukupno != labela1 + labela2 + labela3 + labela4)
            {
                ukupno = labela1 + labela2 + labela3 + labela4;
            }
        }

        private void Srebrena_Unchecked(object sender, RoutedEventArgs e)
        {
            if (ukupno != labela1 + labela2 + labela3 + labela4)
            {
                ukupno = labela1 + labela2 + labela3 + labela4;
            }
        }
       
       

       

     
        
       

       
        
    }
}
