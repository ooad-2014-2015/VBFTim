﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalonLjepoteBelma.Models
{
    public class Raspored
    {
        private string ponedjeljak;

        public string Ponedjeljak
        {
            get { return ponedjeljak; }
            set { ponedjeljak = value; }
        }
        private string utorak;

        public string Utorak
        {
            get { return utorak; }
            set { utorak = value; }
        }
        private string srijeda;

        public string Srijeda
        {
            get { return srijeda; }
            set { srijeda = value; }
        }
        private string cetvrtak;

        public string Cetvrtak
        {
            get { return cetvrtak; }
            set { cetvrtak = value; }
        }
        private string petak;

        public string Petak
        {
            get { return petak; }
            set { petak = value; }
        }
        public Raspored(string p, string u, string s, string c, string pe)
        {
            ponedjeljak = p;
            utorak = u;
            srijeda = s;
            cetvrtak = c;
            petak = pe;
        }
    }
}
