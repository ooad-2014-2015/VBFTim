﻿using System;
using System.Collections.Generic;
using System.Data.Linq;
using System.IO;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace PhonAppSalonLjepoteBelma
{
    public partial class Page1 : PhoneApplicationPage
    {
        private int id;

        public int Id
        {
            get { return id; }
            set { id = value; }
        }
        string imeZaposlenog;

        public string ImeZaposlenog
        {
            get { return imeZaposlenog; }
            set { imeZaposlenog = value; }
        }
        string cijenaUsluge;

        public string CijenaUsluge
        {
            get { return cijenaUsluge; }
            set { cijenaUsluge = value; }
        }
        string dan;

        public string Dan
        {
            get { return dan; }
            set { dan = value; }
        }
        string vrijeme;

        public string Vrijeme
        {
            get { return vrijeme; }
            set { vrijeme = value; }
        }
        public Page1()
        {   
            InitializeComponent();
            /*text1.Text = "Fadil";
            text2.Text = "100";
            text3.Text = "Ponedjeljak";
            text4.Text = "10:00";*/

             

            using (LokalnaBazaBelmaContext db = new LokalnaBazaBelmaContext(LokalnaBazaBelmaContext.ConnectionString))
            {
                db.CreateIfNotExists();
               
                try
                {
                    Table<Transakcije> t = db.GetTable<Transakcije>();
                    var tQuery = from j in t.ToList() select j;
                    foreach (var te in tQuery)
                    {
                        PivotItem p = new PivotItem();
                        //
                        if (id == 4)
                        {
                            text1.Text = te.Ime_Zaposlenog;
                            text2.Text = te.CIjena_Usluge;
                            text3.Text = te.Dan;
                            text4.Text = te.Vrijeme;
                          
                           
                        }

                       
                       /* p.Header =;
                        p.Content = jeloKontrola;
                        mojPivot.Items.Add(p);*/

                    }
                }
                catch (Exception et)
                {

                }
            }
        }

    }
}